import cv2
import numpy as np
import numpy
from PIL import Image

#Input Image
input_img= cv2.imread('./Paper Strip Template 01.jpg')
image = cv2.imread('./Paper Strip Template 01.jpg')
print()

gray_img =  cv2.cvtColor(input_img,cv2.COLOR_BGR2GRAY)
img = cv2.medianBlur(gray_img,	5)
cimg = cv2.cvtColor(img,cv2.COLOR_GRAY2BGR)


#Circle detection using HoughCircle
circles	= cv2.HoughCircles(img,cv2.HOUGH_GRADIENT,1,120,param1=100,param2=30,minRadius=0,maxRadius=0)
circles	= np.uint16(np.around(circles))

#To get the pixel values of image
def get_image(image_path):
    image = Image.open(image_path, "r")
    width, height = image.size
    pixel_values = list(image.getdata())
    return pixel_values
    
#Storing Blue ration of each circle
Blue_Ratio = []
count=1

#calculating RGB ratio
for i in circles[0,:]:
    cv2.circle(input_img,(i[0],i[1]),i[2],(0,255,0),6)				
    cv2.circle(input_img,(i[0],i[1]),2,(0,0,255),3)

    #Crop the circle from image
    crop = image[i[1]-i[2]:i[1]+i[2],i[0]-i[2]:i[0]+i[2]]

    #Store the cropped image
    cv2.imwrite('Circle'+str(count)+'.jpg',crop)

    #Find the pixel values of image
    pixel = get_image('./Circle'+str(count)+'.jpg')
    red   = []
    green = []
    blue  = []

    for pix in pixel:
        if(pix!=(255,255,255) and pix!=(0,0,0)):
            red.append(pix[0])
            green.append(pix[1])
            blue.append(pix[2])

    #Append Green Ratio of Each Circle
    Blue_Ratio.append(round(sum(blue)/len(blue),2))

    #RGB values of Each Circle
    #print("Circle "+str(count))
    #print()
    #print("({:.2f},{:.2f},{:.2f})".format(sum(red)/len(red),sum(green)/len(green),sum(blue)/len(blue)))
    #print()
    count+=1

#Remove the last Blue_Ration value(Its a Square)

Blue_Ratio = Blue_Ratio[:-1]
#minimun of Blue_Ratio is the G value of T circle

#Sort the Blue_Ratio values
#First value belongs to T circle other two values belongs to C and B circle

Blue_Ratio.sort()

circle_t = Blue_Ratio[0]

circle_c_and_b = sum(Blue_Ratio[1:])/2


#Finding the pesticide

y = circle_c_and_b - circle_t

x = (y-6.4)/12.36
if(x<0):
    x=0


print('EPA permissible limit is 0.03ppm')
print()
print('Amount of pesticide in sample = {:.2f} ppm'.format(x))
print()
if(x<=0.03):
    print('SAFE')
elif(x>=0.04 and x<=1.0):
    print('LOW RISK')
elif(x>=1.01 and x<=5.0):
    print('MEDIUM RISK')
else:
    print('HIGH RISK')



#Display Detected Circle
cv2.imshow("Detected Cirlces",input_img)
cv2.waitKey()
cv2.destroyAllWindows()


